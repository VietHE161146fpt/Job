const express = require("express");
const isAuthenticated = require("../middlewares/isAuthenticated.js");
// const { singleUpload } = require("../middlewares/multer.js");
const companyController = require("../controllers/company.controller.js");

const router = express.Router();

router.post("/register", isAuthenticated, companyController.registerCompany);
router.get("/get",isAuthenticated, companyController.getCompany);
router.get("/get/:id", isAuthenticated, companyController.getCompanyById);
router.put(
  "/update/:id",
  isAuthenticated,
  // singleUpload,
  companyController.updateCompany
);

module.exports = router;
